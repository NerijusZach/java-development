public class Tax {
    double grossIncome;
    String state;
    int dependents;

    public double calcTax() {
     
       return 234.55;  
    }

}