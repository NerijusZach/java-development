class Employee implements java.io.Serializable{
     String lName;
     String  fName;
     double salary;
 
}
