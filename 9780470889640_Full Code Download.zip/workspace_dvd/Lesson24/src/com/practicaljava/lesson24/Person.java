package com.practicaljava.lesson24;
abstract public class Person {
  abstract public void raiseSalary();
}
