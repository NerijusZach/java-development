
public class Customer {
    public Customer (String a, String b){}
}
